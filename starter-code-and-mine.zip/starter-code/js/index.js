var $cart = document.querySelector('#cart tbody');
// let cartElement
var $calc = document.getElementById('calc');
// let calcElement

// document.querySelector(".qty input").value

// document.querySelector(".pu span").innerText

// document.querySelector(".subtot span").innerText


function updateSubtot($product) {
  let sum = 0
  let qty = $product.querySelector(".qty input").value;
  let price = $product.querySelector(".pu span").innerText;
  sum = price * qty
  let subtot = $product.querySelector(".subtot span").innerText = sum ;
  
  console.log(subtot)
  // subtot.innerText = qty * pu;
  // return subtot;
}


function calcAll() {
  let product1 = document.querySelector(".product")
  updateSubtot(product1)
}
$calc.onclick = calcAll;



//------secondary option------
// function calcAll() {
  // let allProductElements = document.getElementsByClassName('product')
//   for (let = 0; i < document.getElementsByClassName('product').length; i++) {
//     updateSubtot(document.getElementsByClassName('product')[i]
//   }  }
// }


// calcButton.onClick = calcAll;

/* ------------------------------------------------

let $calc = document.getElementById('calc');
function calcAllHandler() {
  let allProductElements = document.getElementsByClassName('product')
  let price = allProductElements[0].querySelector('.pu span').innerText
  let qty = allProductElements[0].querySelector('input').value
  allProductElements[0].querySelector('.subtot span').innerText = Number(price) * Number(qty)
  let price1 = allProductElements[0].querySelector('.pu span').innerText
  let qty1 = allProductElements[1].querySelector('input').value
  allProductElements[1].querySelector('.subtot span').innerText = Number(price1) * Number(qty1)
}
$calc.onclick = calcAllHandler;
*/